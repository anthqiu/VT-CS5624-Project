TOPIC_KEYWORDS = {
    "racism": ["racism", "racist"],
    # "blm": ["blacklivesmatter", "black lives matter"],
    "police": ["police"],
    "immigration": ["immigration", "immigrant", "immigrants"],
    # "climate": ["climate change", "global warming"],
    # "healthcare": ["health care"],
}

BASE_MODEL_NAME = "roberta-base"
# BASE_MODEL_NAME = "bert-base-uncased"